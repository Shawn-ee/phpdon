<?php

namespace Qcloud\Cos\Exception;

class BucketAlreadyExistsException extends CosException {}
