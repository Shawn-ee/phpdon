<?php

namespace Qcloud\Cos\Exception;

class InvalidArgumentException extends CosException {}
