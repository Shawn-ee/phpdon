<?php
$radar_list = [
    'card',
    'admin'
];

return [
    'card',
    'admin'
];