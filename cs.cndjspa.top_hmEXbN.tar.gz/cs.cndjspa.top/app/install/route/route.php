<?php
use think\facade\Route;
/**
 * @model index
 * @author yangqi
 * @create time 2019年11月25日23:09:59
 * 
 */
Route::get('/', 'index/index');
