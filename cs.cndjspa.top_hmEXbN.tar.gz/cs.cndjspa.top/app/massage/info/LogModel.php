<?php
/**
 * Created by PhpStorm.
 * User: shuixian
 * Date: 2019/11/20
 * Time: 18:29
 */

$data = [

    'shop_cate' => [

        'name' => '物料商场-商品分类',

        'text' => '分类'

    ],
    'shop_goods' => [

        'name' => '物料商场-商品管理',

        'text' => '商品'

    ],
    'service_list' => [

        'name' => '服务管理',

        'text' => '服务'

    ],
    'clock_service_list' => [

        'name' => '加钟服务管理',

        'text' => '服务'

    ],
    'banner_list' => [

        'name' => '轮播图设置',

        'text' => '轮播图'

    ],
    'add_clock_setting' => [

        'name' => '',

        'text' => '加钟设置'

    ],
    'coach_list' => [

        'name' => '技师列表',

        'text' => '技师'

    ],
    'coach_level' => [

        'name' => '技师等级',

        'text' => '等级'

    ],
    'coach_level_period' => [

        'name' => '',

        'text' => '技师等级折算周期'

    ],
    'coach_setting' => [

        'name' => '',

        'text' => '技师管理其他设置'

    ],
    'order_list' => [

        'name' => '服务订单',

        'text' => ''

    ],
    'add_order' => [

        'name' => '加钟订单',

        'text' => ''
    ],
    'refuse_order' => [

        'name' => '拒单管理',

        'text' => ''
    ],
    'refund_order' => [

        'name' => '服务退款',

        'text' => ''
    ],
    'refund_add_order' => [

        'name' => '加钟退款',

        'text' => ''
    ],
    'comment_icon' => [

        'name' => '评价标签',

        'text' => '标签'
    ],
    'comment_list' => [

        'name' => '评价管理',

        'text' => '评价'
    ],
    'distribution_list' => [

        'name' => '分销商审核',

        'text' => '分销商'
    ],
    'distribution_setting' => [

        'name' => '分销设置',

        'text' => '分销设置'
    ],
    'channel_list' => [

        'name' => '渠道商审核',

        'text' => '渠道商'
    ],
    'channel_cate' => [

        'name' => '渠道类目',

        'text' => '类目'
    ],
    'channel_finance' => [

        'name' => '渠道商财务',

        'text' => '渠道商财务'
    ],
    'admin_list' => [

        'name' => '代理商账号',

        'text' => '代理商'
    ],
    'admin_setting' => [

        'name' => '代理商设置',

        'text' => '设置'
    ],
    'article_list' => [

        'name' => '文章管理',

        'text' => '文章'
    ],
    'article_table_list' => [

        'name' => '文章管理-表单字段',

        'text' => '字段'
    ],
    'coupon_list' => [

        'name' => '卡券管理',

        'text' => '卡券'
    ],
    'market' => [

        'name' => '邀请好友活动',

        'text' => '活动'
    ],
    'finance_list' => [

        'name' => '储值管理',

        'text' => '储值套餐'
    ],
    'finance_commission' => [

        'name' => '储值返佣',

        'text' => '储值返佣'
    ],
    'wallet_list' => [

        'name' => '提现申请',

        'text' => '提现'
    ],
    'dynamic_list' => [

        'name' => '动态管理',

        'text' => '动态'
    ],
    'dynamic_comment' => [

        'name' => '动态评论',

        'text' => '动态'
    ],





];


return $data;





