<?php


namespace app\massage\model;


use app\BaseModel;

class CoachTime extends BaseModel
{
    protected $name = 'massage_service_coach_time';
}