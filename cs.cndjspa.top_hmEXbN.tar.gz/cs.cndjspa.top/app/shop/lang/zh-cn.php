<?php
return [
    'not find refundorder' => '未找到退款订单',
    'not find order'       => '未找到订单',
	'status is error'      => '状态错误',
	'Too little money'     => '体现金额不得小于平台最低提现金额',
	'no profit'            => '未找到佣金记录',
	'Insufficient amount'  => '佣金不足',
	'no data'              => '未找到记录',
	'not data'             => '未找到记录',
	'Only offline package can be cancelled' => '只有线下福包才能核销',
	'The coupon has expired'=> '福包已过期',
	'not find card'         => '名片没有找到',
	'no config of pay'      => '未配置支付信息',
];