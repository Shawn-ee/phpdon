<?php
// +----------------------------------------------------------------------
// | Longbing [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright Chengdu longbing Technology Co., Ltd.
// +----------------------------------------------------------------------
// | Website http://longbing.org/
// +----------------------------------------------------------------------
// | Sales manager: +86-13558882532 / +86-13330887474
// | Technical support: +86-15680635005
// | After-sale service: +86-17361005938
// +----------------------------------------------------------------------

declare(strict_types=1);

namespace longbingcore\diy;

use app\BaseControllerV2;
use think\Request;

/**
 * @author shuixian
 * @DataTime: 2019/12/11 17:04
 * Class BaseSubscribe
 * @package longbingcore\diy
 */
class BaseSubscribe
{
    public function __construct(Request $request)
    {
      //  parent::__construct($request);
    }

}