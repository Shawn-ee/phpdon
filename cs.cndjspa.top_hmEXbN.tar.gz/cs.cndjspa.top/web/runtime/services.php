<?php 
// This cache file is automatically generated at:2019-07-01 11:25:20
declare (strict_types = 1);
return array (
  0 => 'think\\migration\\Service',
);