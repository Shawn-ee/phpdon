import survey from './survey'

export default {
  ...survey
}
