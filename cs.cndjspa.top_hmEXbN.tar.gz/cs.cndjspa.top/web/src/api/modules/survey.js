import { get } from '../index'

export default {
  getRoutes () {
    return get('/admin/test')
  }
}
