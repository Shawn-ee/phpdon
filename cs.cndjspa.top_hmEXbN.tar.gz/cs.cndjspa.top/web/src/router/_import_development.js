module.exports = file => require('@/view' + file + '.vue').default
