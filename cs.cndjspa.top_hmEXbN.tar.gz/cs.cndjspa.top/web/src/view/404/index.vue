<template>
    <div>
        {{key}}
    </div>
</template>

<script>
export default {
  data () {
    return {
      key: '页面不存在'
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
