<template>
<!-- 登录 -->
    <div>
        {{key}}
    </div>
</template>

<script>
export default {
  name: 'Login',
  data () {
    return {
      key: '登录页面'
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
